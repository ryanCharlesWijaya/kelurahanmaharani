

<?php $__env->startSection('container'); ?>
<style>
    
</style>
<h1 style="padding-top:4%;">Informasi Arsip</h1>
<form id="form-arsip" method="POST" action="<?php echo e(route('arsip.updateInfo', ['id' => $arsip->id])); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="jenis_dokumen"><?php echo e(__('Jenis Dokumen')); ?></label>
        <input type="text" list="jenis_jenis_dokumen" class="form-control" id="jenis_dokumen" name="jenis_dokumen" placeholder="Kode Dokumen" value="<?php echo e($arsip->jenisDokumen->name); ?>">
        <datalist id="jenis_jenis_dokumen">
            <?php $__currentLoopData = $jenisJenisDokumen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenisDokumen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option class="option-<?php echo e($jenisDokumen['id']); ?>"><?php echo e($jenisDokumen['name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </datalist>

        <?php $__errorArgs = ['jenis_dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="kode_dokumen"><?php echo e(__('Kode Dokumen')); ?></label>
        <input type="text" class="form-control" id="kode_dokumen" name="kode_dokumen" placeholder="Kode Dokumen" value="<?php echo e($arsip->kode_dokumen); ?>">

        <?php $__errorArgs = ['kode_dokumen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="keterangan"><?php echo e(__('Keterangan')); ?></label>
        <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="Keterangan" value="<?php echo e($arsip->keterangan); ?>">

        <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <button type="submit" class="btn btn-success">Update</button>
</form>
<br>
<form action="<?php echo e(route('arsip.updateFile', ['id' => $arsip->id])); ?>" method="POST" enctype="multipart/form-data">
    <h2>File</h2>
    <?php echo csrf_field(); ?>
    <div class="form-group files color">
        <label>Upload Your File </label>
        <input type="file" id="file" class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file" value="<?php echo e(old('file')); ?>" required autocomplete="file" autofocus>

        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="button-group">
        <button type="submit" class="btn btn-success mb-4">Simpan Perubahan File</button>
    </div>
</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Venny\kelurahanmaharani\resources\views/arsip/arsipEdit.blade.php ENDPATH**/ ?>