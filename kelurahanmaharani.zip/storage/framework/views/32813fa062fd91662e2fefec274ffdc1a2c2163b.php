

<?php $__env->startSection('container'); ?>
    <div id="container" class="row container">
        <h1 class="dashboard-title">Selamat Datang</h1>
        <!-- <div class="card-deck col-md-16 mydeck">
            <div class="card text-center mycard" style="border-radius:20px;">
                <div class="card-body">
                    <h5 class="card-title ">Total</h5>
                    <h1 class="text-success">100 Upload</h1>
                    <h5>Hari Ini</h5>
                </div>
            </div>
            <div class="card text-center mycard" style="border-radius:20px;">
                <div class="card-body">
                    <h5 class="card-title ">Total</h5>
                    <h1 class="text-primary">100 Upload</h1>
                    <h5>Minggu Ini</h5>
                </div>
            </div>
            <div class="card text-center mycard" style="border-radius:20px;">
                <div class="card-body">
                    <h5 class="card-title ">Total</h5>
                    <h1 class="text-danger">100 Upload</h1>
                    <h5>Bulan Ini</h5>
                </div>
            </div>
        </div> -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Venny\kelurahanmaharani\resources\views/dashboard.blade.php ENDPATH**/ ?>